from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.orm import relationship
from app.services.db import Base

class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=True)

    books = relationship("Book", back_populates="category")
